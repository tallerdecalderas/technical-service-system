# Backend Architecture Skills

Este paquete contiene dos skills independientes para planificar backends con criterio de arquitectura y operaciones:

1. **backend-core-architecture**: define qué capacidades conviene implementar y controlar dentro del backend.
2. **backend-provider-strategy**: decide qué capacidades conviene consumir como servicio externo, autohospedar o mantener detrás de un adaptador.

## Uso

Copiá la carpeta de la skill que necesites al directorio de skills que utilice tu agente. También podés instalar ambas. Conservá el nombre de cada carpeta y su `SKILL.md`.

El agente debe leer `SKILL.md` y consultar los archivos de `references/` cuando correspondan. Las skills son agnósticas del lenguaje: deben adaptar ejemplos y librerías a la tecnología real del proyecto.

## Comportamiento esperado

- Preguntar de forma progresiva, una pregunta importante por vez.
- Reutilizar el contexto que ya conoce; no repetir preguntas respondidas.
- Separar lógica de negocio, capacidades de aplicación e infraestructura.
- Diferenciar construir código propio, integrar software open source autohospedado y contratar un proveedor administrado.
- Justificar decisiones, riesgos, costos operativos y estrategia de salida.
- No agregar complejidad sin una necesidad demostrable.
