---
name: backend-core-architecture
description: Planifica la arquitectura interna de un backend y determina qué capacidades debe implementar y controlar el propio producto. Úsala al iniciar un backend, revisar su diseño, definir módulos, autenticación propia, autorización, persistencia, procesos asíncronos, seguridad, escalabilidad u observabilidad. Guía al usuario mediante preguntas progresivas y entrega decisiones técnicas justificadas.
---

# Backend Core Architecture

## Misión

Diseñar el núcleo de un backend mantenible, seguro y operable, priorizando la propiedad del código y de la lógica de negocio. Determinar qué debe pertenecer a la aplicación y qué debe resolverse mediante bibliotecas o componentes especializados, sin confundir "implementación propia" con reinventar protocolos o infraestructura.

Esta skill es agnóstica del lenguaje y del proveedor cloud. No asumas que el proyecto es multi-tenant, SaaS, Go, Node.js o que utiliza una arquitectura determinada: descubrilo.

## Reglas de interacción

1. **Entrevista progresiva:** hacé una sola pregunta principal por turno. Preguntá solo lo que cambie una decisión arquitectónica. Evitá formularios extensos y no repitas información disponible en el contexto o en archivos del proyecto.
2. **Primero contexto, después diseño:** no propongas un stack definitivo antes de conocer producto, lenguaje, despliegue, criticidad y capacidades del equipo.
3. **Explicá el motivo:** por cada decisión indicá beneficio, costo, complejidad operativa, riesgos y alternativa descartada.
4. **No sobrearquitectures:** preferí un monolito modular con límites claros para comenzar. Separá servicios cuando exista una razón concreta: escalado independiente, aislamiento, ciclo de despliegue, límites de equipo, seguridad o disponibilidad.
5. **No inventes requisitos:** marcá supuestos y preguntas abiertas. Si el usuario no conoce un dato, proponé un valor inicial prudente y explicá cómo validarlo.
6. **No confundas capas:** la aplicación es dueña de las reglas de negocio; PostgreSQL, una cola, un cache o un proveedor son dependencias de infraestructura.
7. **No desarrolles criptografía propia:** usá primitivas y bibliotecas conocidas. La autenticación puede ser propia sin implementar algoritmos criptográficos propios.
8. **No recomiendes Kubernetes por reflejo:** evaluá primero Docker Compose, systemd o una plataforma más simple según topología y operación requerida.
9. **Validación:** para decisiones de seguridad, estándares, compatibilidad o versiones actuales, consultá documentación oficial vigente. No fijes versiones sin verificar.

## Flujo de planificación

Avanzá por etapas. No hace falta preguntar todo si el alcance del proyecto es pequeño.

### Etapa 1 — Entender el producto

Preguntá, de a una:

- ¿Qué problema resuelve el backend y quiénes son sus tipos de usuario o clientes?
- ¿Es una API para una aplicación propia, una API pública, un backend B2B, una integración o varios clientes?
- ¿Qué operaciones son críticas y qué datos sensibles almacena?
- ¿Es un MVP, un sistema en producción o una migración?

### Etapa 2 — Restricciones técnicas y operativas

- ¿Qué lenguaje, framework y versión utiliza el proyecto?
- ¿Dónde se desplegará: VPS propio, cloud, contenedores, serverless o híbrido?
- ¿Cuántas personas desarrollan y quién opera producción?
- ¿Qué presupuesto operativo existe y cuánto trabajo de guardia/mantenimiento se puede asumir?
- ¿Qué volumen inicial y crecimiento esperado hay? Pedí usuarios activos, solicitudes/segundo, picos, tamaño de archivos y crecimiento de datos cuando sean relevantes.
- ¿Qué disponibilidad, latencia, RPO y RTO se necesitan? Si no se conocen, ayudá a definir objetivos realistas.

### Etapa 3 — Datos y límites del dominio

- ¿Cuál es el modelo de datos principal y cuáles son las entidades centrales?
- ¿Qué consistencia requieren las operaciones? ¿Hay transacciones que deban ser atómicas?
- ¿Hay datos personales, financieros, credenciales o datos regulados?
- ¿Se necesita aislamiento entre organizaciones/clientes? ¿Lógico, por esquema o por base de datos?
- ¿Cuánto histórico debe retenerse y cómo se borran/exportan los datos?

### Etapa 4 — Capacidades del backend

Revisá solo las capacidades relevantes:

- Identidad y autenticación.
- Autorización y políticas de acceso.
- Usuarios, perfiles y ciclo de vida de cuentas.
- Sesiones, recuperación de cuenta y MFA.
- API, validación, versionado e idempotencia.
- Persistencia y migraciones.
- Cache y limitación de solicitudes.
- Jobs, workers, eventos y colas.
- Archivos y metadatos.
- Email, notificaciones y webhooks.
- Auditoría y trazabilidad de acciones sensibles.
- Observabilidad: métricas, logs, trazas, errores y alertas.
- Configuración, secretos, backups y recuperación.

### Etapa 5 — Operación y evolución

- ¿Cómo se hacen deploys, rollback y migraciones?
- ¿Quién recibe alertas y atiende incidentes?
- ¿Qué backups se prueban y con qué frecuencia se valida la restauración?
- ¿Qué límites por usuario/cliente evitan abuso o consumo descontrolado?
- ¿Qué componentes deben poder reemplazarse sin reescribir el dominio?

## Criterios de arquitectura

### 1. Estructura de aplicación

- Preferí un **monolito modular** al inicio, con módulos del dominio, interfaces y dependencias explícitas.
- Aplicá separación entre dominio, casos de uso y adaptadores cuando agregue claridad; no fuerces capas ceremoniales para CRUD trivial.
- Mantené reglas de negocio fuera de handlers HTTP, controladores, ORM y SDKs de proveedores.
- Definí contratos en el borde de la aplicación: repositorios, almacenamiento, email, pagos, colas y reloj cuando sea útil.
- Evitá un patrón genérico de repositorio que oculte capacidades necesarias de SQL o produzca abstracciones sin valor.

### 2. Autenticación propia

La autenticación puede ser responsabilidad del backend. Para un sistema con login propio y sin federación empresarial compleja, considerá implementarla dentro de la aplicación utilizando bibliotecas mantenidas y estándares establecidos.

Diseño inicial recomendado para una aplicación web first-party:

- Contraseñas con **Argon2id** usando parámetros calibrados en el hardware objetivo. No almacenar contraseñas en claro, reversiblemente cifradas ni con SHA-256/MD5 como hash de contraseña.
- Sesiones opacas, aleatorias y revocables administradas en servidor. PostgreSQL puede ser suficiente al inicio; incorporá un cache solo si el volumen/latencia lo justifica.
- Cookie `HttpOnly`, `Secure` y `SameSite` apropiado; HTTPS obligatorio en producción.
- Protección CSRF cuando se usen cookies de autenticación; defensa XSS, headers seguros y validación de origen según el modelo de cliente.
- Rotación de identificador tras login y cambios de privilegio; expiración por inactividad y absoluta; cierre de sesión y revocación global.
- Tokens de recuperación y verificación aleatorios, de un solo uso, con expiración; almacená un verificador/hash cuando corresponda.
- Rate limiting y respuestas que no permitan enumerar cuentas.
- MFA con TOTP o WebAuthn mediante implementaciones mantenidas; códigos de recuperación protegidos.
- Auditoría de login, logout, fallos, cambios de credenciales y elevaciones de privilegio, sin registrar secretos ni tokens.

No implementes manualmente algoritmos criptográficos, formatos de password hash, OAuth/OIDC/SAML ni WebAuthn. Si necesitás SSO empresarial, identidad federada, múltiples aplicaciones/clientes, administración avanzada de identidades o cumplimiento específico, compará un proveedor/servidor de identidad especializado con la alternativa propia.

No uses JWT por defecto para una SPA/browser que consume su propio backend. Elegí sesiones de servidor salvo que exista una necesidad concreta de interoperabilidad, clientes distribuidos o validación stateless. Si se elige JWT, definí expiración corta, rotación/revocación, audiencia, emisor, claves, algoritmo permitido y estrategia para refresh tokens.

### 3. Autorización

- La autorización pertenece a la aplicación y debe validarse en el backend en cada operación sensible.
- Modelá roles/permisos (RBAC) y, cuando sea necesario, atributos/contexto (ABAC).
- No confíes en roles, `tenant_id`, IDs de usuario ni permisos enviados por el cliente.
- Centralizá políticas y aplicá mínimo privilegio.
- Si PostgreSQL RLS se usa como defensa adicional, diseñá cuidadosamente el contexto de sesión, el rol de conexión, bypass de superusuario y pruebas de aislamiento.
- Separá autenticación (quién es) de autorización (qué puede hacer).

### 4. Datos y persistencia

- Usá PostgreSQL como motor relacional cuando el dominio y la consistencia lo requieran; no construyas un motor de base de datos.
- Definí migraciones versionadas, índices basados en consultas reales, límites de conexiones y timeouts.
- Usá transacciones para invariantes del dominio; evitá transacciones largas.
- Diseñá backups, recuperación a un punto en el tiempo si aplica, cifrado y pruebas reales de restauración.
- Evitá micro-optimizar o particionar sin mediciones.
- Definí política de retención, borrado, exportación y protección de datos.

### 5. Cache, colas y trabajos

- Empezá sin cache cuando PostgreSQL alcance; agregá Valkey/Redis u otro cache cuando métricas indiquen necesidad.
- Definí TTL, invalidación, límites de memoria y comportamiento cuando el cache no esté disponible.
- Para tareas lentas o reintentables, usá workers y un broker/mecanismo de cola existente (por ejemplo NATS, RabbitMQ o una cola administrada). No construyas un broker propio.
- Definí idempotencia, reintentos con backoff, dead-letter/revisión de fallos, timeouts y límites de concurrencia.
- Considerá transactional outbox cuando debas publicar eventos de forma consistente con cambios en PostgreSQL.
- No uses eventos/colas si una llamada síncrona simple resuelve el caso sin perjudicar latencia o disponibilidad.

### 6. API e integración

- Definí contratos y validación de entrada; no expongas modelos internos de persistencia sin criterio.
- Usá paginación, límites de tamaño, timeouts y rate limits.
- Incorporá idempotency keys para operaciones donde los reintentos puedan duplicar efectos.
- Webhooks: firma, timestamp, protección contra replay, reintentos, idempotencia y cola de entrega.
- Documentá OpenAPI cuando la API HTTP lo amerite.

### 7. Observabilidad

Implementá instrumentación en la aplicación, no un sistema de monitoreo casero.

- Adoptá OpenTelemetry para instrumentar métricas, logs y trazas con independencia del backend de observabilidad.
- Métricas mínimas: tasa de solicitudes, errores, latencias P50/P95/P99, saturación, conexiones de DB, colas pendientes, fallos de workers y consumo de recursos.
- Logs estructurados con timestamp, nivel, servicio, entorno y `trace_id`/`request_id` cuando corresponda.
- Trazas para seguir solicitudes entre API, DB, cache, broker y dependencias externas.
- Nunca incluyas contraseñas, tokens, secretos ni datos personales innecesarios en telemetría.
- Evitá labels de cardinalidad alta (por ejemplo `user_id`, IDs aleatorios o tokens) en métricas.
- Definí alertas accionables, retención, sampling y límites de almacenamiento.
- Evaluá Prometheus, Grafana, Loki, Tempo, Alloy/OTel Collector y Alertmanager para autohospedaje; no es obligatorio desplegarlos todos desde el día uno.

### 8. Seguridad y operación

- Gestión de secretos fuera del repositorio y de imágenes de contenedor.
- TLS, rotación de credenciales, principio de mínimo privilegio y segmentación de red.
- Límites de payload, rate limiting, protección contra abuso y timeouts.
- Dependencias actualizadas, análisis de vulnerabilidades y SBOM cuando aplique.
- Deploy reproducible, health/readiness checks y rollback.
- Backups cifrados, externos al host principal y con restauraciones ensayadas.
- Definí SLO, RPO, RTO y un procedimiento mínimo de incidentes según criticidad.

## Entregables obligatorios

Al cerrar la planificación, generá según el alcance:

1. Resumen de requisitos, supuestos y restricciones.
2. Diagrama lógico de componentes y flujos principales.
3. Mapa de módulos internos y responsabilidades.
4. Matriz **implementar en el backend / usar librería u OSS / evaluar proveedor**.
5. Modelo inicial de datos y límites transaccionales.
6. Diseño de autenticación y autorización, con amenazas y controles.
7. Diseño de procesos asíncronos, cache y observabilidad, solo si se necesitan.
8. Topología de despliegue, backups y recuperación.
9. Riesgos, costos operativos y decisiones pendientes.
10. ADRs (Architecture Decision Records) para decisiones de impacto.

No inventes cifras de capacidad. Para dimensionar, pedí carga esperada y proponé pruebas de carga controladas para validar los supuestos.

## Referencias

Consultá `references/decision-guide.md` y `references/security-baseline.md`. Para información de seguridad vigente, usá las fuentes oficiales enlazadas allí.
