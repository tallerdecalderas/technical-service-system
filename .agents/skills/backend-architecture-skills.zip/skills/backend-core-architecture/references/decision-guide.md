# Guía de decisiones para el núcleo del backend

## Clasificación

Para cada capacidad, elegí y justificá una de estas opciones:

- **Código propio:** reglas de negocio y comportamiento específico del producto.
- **Biblioteca/framework:** implementación local de una función conocida (hashing, validación, SDK, protocolo). No reinventar el estándar.
- **OSS autohospedado:** componente independiente que el equipo opera (PostgreSQL, Valkey, NATS, Prometheus, etc.).
- **Proveedor administrado:** servicio externo que reduce trabajo operativo o aporta una capacidad difícil de replicar.

## Matriz de partida

| Capacidad | Preferencia inicial | Cuándo cambiar |
|---|---|---|
| Reglas de negocio | Código propio | No externalizar el dominio central |
| Auth de usuario/password básica | Código propio + bibliotecas seguras | SSO/federación, múltiples apps, requisitos enterprise o falta de capacidad de operación |
| Autorización | Código propio | Servicio de políticas si la complejidad distribuida lo justifica |
| Sesiones | Código propio + PostgreSQL | Cache/store dedicado por carga o topología |
| Hash de contraseñas | Biblioteca mantenida (Argon2id) | Nunca implementar criptografía propia |
| SQL/ORM/migraciones | Librerías existentes + PostgreSQL | DB administrada si el costo operativo lo amerita |
| Cache | Sin cache al inicio; luego Valkey/Redis | Administrado si operar cache no compensa |
| Colas | Worker simple/DB si es muy pequeño; luego NATS/RabbitMQ | Broker administrado si disponibilidad/operación lo requiere |
| Jobs | Código propio del caso de uso + motor/cola existente | Plataforma administrada si volumen y operación lo justifican |
| Observabilidad | Instrumentación OTel propia + stack OSS o administrado | Backend administrado si retención, escala o guardia propia son costosas |
| Archivos | Módulo propio + API S3 | Storage administrado o clúster OSS según volumen y egress |
| Email/SMS/WhatsApp | Lógica y plantillas propias; transporte externo | Autohospedar solo si existe una razón operativa fuerte |
| Pagos | Integración con procesador externo | No almacenar/procesar tarjetas directamente salvo programa de cumplimiento adecuado |
| CDN/DDoS | Proveedor especializado | Autogestión no suele ser razonable a pequeña escala |
| Búsqueda | PostgreSQL FTS al inicio | Meilisearch/OpenSearch o servicio administrado por relevancia/volumen |
| IA | Capa de abstracción propia + API/modelo seleccionado | Autohospedar modelos cuando costo, privacidad o latencia lo justifiquen |

## Preguntas de diseño que cambian la decisión

1. ¿La capacidad representa una regla diferencial del producto o es infraestructura commodity?
2. ¿Qué pasa si el servicio queda fuera de línea durante 15 minutos? ¿Y durante 4 horas?
3. ¿Quién actualiza, parchea, respalda, monitorea y atiende incidentes?
4. ¿El equipo conoce esa tecnología en producción?
5. ¿Qué es más caro en 12-24 meses: factura del proveedor o infraestructura + guardia + backups + upgrades + incidentes?
6. ¿Cómo se exportan los datos y se migra a otra implementación?
7. ¿Qué datos salen del entorno y qué obligaciones de privacidad/residencia existen?

## Reglas de diseño

- Crear interfaces solo alrededor de dependencias que probablemente cambien o que convenga sustituir/testear.
- Mantener tipos y errores del proveedor fuera del dominio.
- Usar adaptadores; no crear una abstracción universal que limite funcionalidades necesarias.
- Documentar timeouts, retry, circuit breaker, idempotencia y fallback.
- Para fallas de proveedor, decidir si la operación falla cerrada, se degrada o queda en cola.
- Registrar costos y límites por servicio; configurar cuotas y alertas.
