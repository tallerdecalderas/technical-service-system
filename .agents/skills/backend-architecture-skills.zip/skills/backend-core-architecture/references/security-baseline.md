# Baseline de seguridad para autenticación propia

Este documento es una lista de verificación, no una certificación. Adaptar al modelo de amenazas y consultar la versión actual de las guías oficiales.

## Credenciales

- Argon2id (o algoritmo recomendado por el estándar aplicable) con salt único y parámetros calibrados en producción.
- No usar MD5, SHA-1 o SHA-256 directo para almacenar contraseñas.
- Comparaciones y bibliotecas criptográficas de implementación confiable.
- Límites de longitud y tamaño de entrada para evitar consumo abusivo.
- Rehash progresivo cuando se actualicen parámetros.

## Sesiones web

- Identificador aleatorio no predecible con al menos 128 bits de entropía; preferir mayor margen.
- Guardar en servidor el estado de sesión y permitir revocación.
- Preferir almacenar un verificador/hash del secreto de sesión si el modelo de amenaza incluye lectura de la tabla/backups.
- Cookie Secure, HttpOnly, SameSite apropiado y Path limitado; evaluar prefijo `__Host-`.
- Regenerar sesión al autenticar y cambiar privilegios.
- Expiración por inactividad y absoluta.
- No guardar tokens en localStorage/sessionStorage.
- CSRF tokens y controles de origen cuando corresponda; SameSite es defensa adicional, no sustituto universal.
- No registrar cookies ni tokens; usar `Cache-Control: no-store` donde se exponga información sensible.

## Recuperación y MFA

- Token de recuperación aleatorio, un solo uso, expiración corta y verificación segura.
- Invalidar sesiones adecuadamente tras recuperación/cambio de credencial.
- MFA TOTP/WebAuthn usando librerías mantenidas.
- Proteger semillas TOTP y códigos de recuperación; registrar cambios de factores.
- Evitar enumeración de cuentas y aplicar limitación de intentos.

## Referencias oficiales

- OWASP Password Storage Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
- OWASP Session Management Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html
- OWASP Authentication Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html
- OWASP CSRF Prevention Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html
- OWASP ASVS: https://owasp.org/www-project-application-security-verification-standard/
- OpenTelemetry docs: https://opentelemetry.io/docs/
- PostgreSQL Row Security: https://www.postgresql.org/docs/current/ddl-rowsecurity.html
