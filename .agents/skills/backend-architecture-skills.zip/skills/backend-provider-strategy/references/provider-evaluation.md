# Evaluación de proveedores y servicios autohospedados

## Plantilla de evaluación

| Criterio | Opción A | Opción B | Opción C | Evidencia/pregunta pendiente |
|---|---|---|---|---|
| Funcionalidad y límites | | | | |
| Seguridad y cumplimiento | | | | |
| Región y residencia de datos | | | | |
| Disponibilidad/SLA | | | | |
| Rendimiento y límites | | | | |
| Costos fijos | | | | |
| Costos variables/egress | | | | |
| Backups y recuperación | | | | |
| Operación y soporte | | | | |
| Licencia | | | | |
| Portabilidad/exportación | | | | |
| Tiempo de implementación | | | | |
| Riesgo de lock-in | | | | |

## Preguntas para un proveedor

- ¿En qué regiones almacena y procesa los datos?
- ¿Qué SLA ofrece y qué exclusiones contiene?
- ¿Qué límites de API, concurrencia, tamaño, almacenamiento y requests aplica?
- ¿Cómo se calculan costos de uso, transferencia, operaciones, retención y soporte?
- ¿Qué ocurre ante overage y cómo se configuran alertas/cuotas?
- ¿Qué mecanismos de backup, restore, exportación y borrado definitivo ofrece?
- ¿Qué controles de cifrado, aislamiento, auditoría y gestión de claves ofrece?
- ¿Cómo se notifican incidentes y cambios incompatibles?
- ¿Se puede migrar a una implementación compatible? ¿Qué datos/configuración no son portables?
- ¿Qué obligaciones tiene la licencia o el contrato para el uso comercial?

## Checklist de lock-in

- [ ] Datos exportables en formato documentado.
- [ ] Esquema de datos controlado por el equipo cuando sea posible.
- [ ] Adaptador interno sin tipos propietarios en el dominio.
- [ ] Configuración e infraestructura versionadas.
- [ ] Pruebas de contrato para el adaptador.
- [ ] Procedimiento de migración y estimación del downtime.
- [ ] Plan para DNS, secretos, webhooks y credenciales durante el cambio.
- [ ] Prueba periódica de exportación/restauración.

## Ejemplo de ADR

### ADR-NNN: Selección de [servicio]

- **Estado:** Propuesto / Aceptado / Reemplazado.
- **Fecha:** YYYY-MM-DD.
- **Contexto:** problema, volumen, criticidad y restricciones.
- **Opciones:** build-in-app, OSS self-hosted, managed providers.
- **Decisión:** opción seleccionada y alcance.
- **Motivos:** funcionalidad, TCO, operación, seguridad y portabilidad.
- **Consecuencias:** costos, deuda operativa, lock-in y responsabilidades.
- **Plan de salida:** cómo sustituir/migrar y qué validar.
- **Revisión:** fecha o condición que fuerza reevaluación.
