---
name: backend-provider-strategy
description: Evalúa qué capacidades de un backend conviene contratar a un proveedor, autohospedar con software open source o implementar dentro de la aplicación. Úsala al seleccionar servicios externos, comparar costos y lock-in, diseñar adaptadores, planificar migraciones o decidir entre managed services y self-hosting. Conduce una entrevista progresiva y entrega una matriz build/buy/self-host.
---

# Backend Provider Strategy

## Misión

Ayudar a decidir con criterio cuándo utilizar un proveedor externo, cuándo autohospedar software open source y cuándo escribir código dentro del backend. El objetivo es minimizar el costo total y el riesgo operativo sin ceder innecesariamente el control del dominio del producto.

No asumas que un proveedor es mejor por ser administrado ni que self-hosting es gratis por ser open source. Considerá facturas, ingeniería, guardias, seguridad, backups, upgrades, disponibilidad, salida y costo de oportunidad.

## Reglas de interacción

1. Hacé preguntas progresivas, una por turno. Usá información ya conocida y no repitas preguntas respondidas.
2. Empezá por el servicio que se está evaluando y por qué surgió la necesidad.
3. Compará siempre tres opciones cuando existan: construir dentro de la aplicación, autohospedar OSS y contratar managed service.
4. Separá **proveedor** de **producto**: por ejemplo, la aplicación puede implementar el módulo de archivos y consumir storage S3 de distintos proveedores.
5. No recomiendes un proveedor concreto sin conocer región, presupuesto, volumen, cumplimiento, integración y precios vigentes. Verificá documentación, SLA, límites y tarifas oficiales actuales.
6. Revisá licencia y modelo de negocio del software autohospedado. "Open source", "source available" y "free tier" no son equivalentes.
7. No externalices la lógica diferencial del negocio. Externalizá transporte, capacidad commodity o infraestructura especializada cuando tenga sentido.
8. Toda dependencia externa necesita plan de fallas, límites, observabilidad, seguridad y salida.

## Flujo de entrevista

### Paso 1 — Identificar la capacidad

Preguntá: ¿Qué querés resolver exactamente (auth, DB, storage, email, pagos, cache, cola, observabilidad, CDN, IA u otro) y qué problema actual te lleva a evaluarlo?

### Paso 2 — Entender el uso

Preguntá de a una:

- ¿Qué volumen inicial y pico se espera (requests/s, GB, mensajes/día, usuarios, transacciones)?
- ¿Qué latencia y disponibilidad exige?
- ¿Qué ocurre si el servicio se cae? ¿Puede esperar, reintentarse o debe funcionar siempre?
- ¿Qué datos se envían, en qué región se procesan y qué requisitos de privacidad, residencia o cumplimiento aplican?
- ¿Hay dependencia de una API, protocolo o ecosistema externo?

### Paso 3 — Capacidad operativa

- ¿El equipo sabe desplegar, actualizar, respaldar y monitorear ese componente?
- ¿Quién atiende incidentes fuera de horario?
- ¿Hay infraestructura redundante, backups externos y capacidad de restauración?
- ¿Cuánto tiempo de ingeniería mensual se puede destinar a operarlo?

### Paso 4 — Economía y salida

- ¿Cuál es el presupuesto y el horizonte de comparación (12/24/36 meses)?
- ¿Qué costos variables importan: almacenamiento, operaciones, transferencia, requests, usuarios, mensajes, soporte o licencias?
- ¿Hay límites, overages, mínimos, costos de salida o soporte pago?
- ¿Se pueden exportar todos los datos y configuraciones? ¿Cuánto cuesta migrar?
- ¿Qué sucede si el proveedor cambia precios, API, licencia o deja de ofrecer el servicio?

## Marco de decisión

Evaluá cada opción en una matriz de 1 a 5 y explicá el peso de cada criterio:

- Ajuste funcional y madurez.
- Seguridad y cumplimiento.
- Disponibilidad y recuperación.
- Costo total a 12/24/36 meses.
- Complejidad de operación y guardia.
- Rendimiento y escalabilidad.
- Control de datos y residencia.
- Portabilidad y costo de salida.
- Velocidad de implementación.

No uses una puntuación agregada ciegamente: una exigencia obligatoria de cumplimiento, residencia o disponibilidad puede descartar una opción aunque su promedio sea alto.

### Costo total de propiedad (TCO)

Compará al menos:

**Managed:** tarifa base + uso + transferencia/egress + soporte + almacenamiento/retención + costos de integración + riesgo de overage.

**Self-hosted:** VPS/servidores + discos/backup + tráfico + redundancia + monitoreo + licencias/soporte + horas de instalación/upgrade/guardia + incidentes + recuperación.

**Build in-app:** ingeniería inicial + mantenimiento + revisiones de seguridad + soporte + costo de oportunidad + riesgo técnico.

No declares que una alternativa es más barata sin volumen, horizonte y supuestos. Mostrá un escenario bajo/base/pico cuando tenga sentido.

## Guía inicial por categoría

### Autenticación e identidad

- Para email/password y sesiones de una aplicación propia, es razonable implementar el flujo dentro del backend usando bibliotecas seguras y estándares establecidos.
- No escribir criptografía propia ni implementar manualmente protocolos OIDC, OAuth2, SAML o WebAuthn.
- Evaluar un Identity Provider cuando se requieran SSO empresarial, federación, múltiples aplicaciones/tenants, aprovisionamiento corporativo, administración avanzada o menor carga de seguridad/operación.
- Separar siempre autenticación (identidad) de autorización (permisos de dominio). La autorización de negocio suele permanecer en el backend.

### Base de datos

- No construir un motor de base de datos. PostgreSQL puede autohospedarse o contratarse como servicio.
- Managed DB suele convenir cuando HA, backups, upgrades, failover y operación superan la capacidad del equipo.
- Self-host PostgreSQL puede convenir con experiencia, carga estable, control de infraestructura y una estrategia real de redundancia/recuperación.
- Una única instancia en un VPS no equivale a alta disponibilidad.

### Object Storage

- Implementar en el backend el módulo de archivos, permisos, metadatos, cuotas, políticas de retención y URLs firmadas.
- Usar una API compatible con S3 para poder sustituir el backend de almacenamiento.
- Comparar storage administrado (por ejemplo, R2 u otro S3-compatible) con soluciones OSS autohospedadas como SeaweedFS, Garage o Ceph según escala y experiencia.
- Comparar costo de almacenamiento, operaciones, egress, replicación, durabilidad, lifecycle, versionado y recuperación.
- No guardar archivos grandes en PostgreSQL salvo una necesidad justificada.

### Email, SMS y mensajería

- Mantener dentro de la aplicación los eventos, reglas, plantillas, preferencias, reintentos y registro de entrega.
- Externalizar normalmente el transporte de email/SMS/WhatsApp. La entregabilidad, reputación, carrier y cumplimiento son trabajo especializado.
- Si se autohospeda SMTP, evaluar reputación IP, SPF, DKIM, DMARC, bounce/complaint handling, blocklists, PTR, límites y soporte operativo.
- Firmar/verificar webhooks, proteger contra replay, usar idempotencia y reintentos.

### Pagos

- Utilizar un procesador de pagos especializado. No almacenar datos completos de tarjetas ni asumir alcance PCI sin un programa de cumplimiento y arquitectura apropiados.
- El backend conserva órdenes, estados internos, conciliación, idempotencia y reglas comerciales.
- Validar webhooks del procesador y no confiar únicamente en el redirect del navegador.
- Comparar comisiones, moneda, liquidación, contracargos, disponibilidad regional, API y exportación de datos.

### Cache, colas y workers

- Cache: empezar sin él si la DB resuelve la carga; después evaluar Valkey/Redis administrado o autohospedado.
- Mensajería: usar NATS/RabbitMQ/Kafka u otro broker existente si hay necesidad real; no desarrollar un broker.
- Managed messaging puede reducir operación; self-hosting ofrece control pero exige HA, upgrades, monitoreo y recuperación.
- La lógica del job, idempotencia y tratamiento del error permanecen en el backend.

### Observabilidad

- La instrumentación y el contexto de negocio pertenecen al código propio. OpenTelemetry reduce acoplamiento con un vendor.
- Autohospedar Prometheus/Grafana/Loki/Tempo/Alloy puede ser adecuado con capacidad operativa.
- Un proveedor administrado puede convenir por retención, búsqueda, alertas, soporte, escala o falta de guardia disponible.
- Comparar ingestión, cardinalidad, retención, sampling, egress, límites y costos por GB/serie/host.
- No construir un sistema de métricas/logs/trazas desde cero.

### CDN, DNS y protección DDoS

- Normalmente contratar un proveedor especializado: red global, peering, mitigación DDoS y DNS anycast son difíciles de replicar.
- Mantener configuración exportable, control del dominio, backups de zonas y procedimiento de cambio de proveedor.

### Búsqueda e IA

- Búsqueda simple: empezar con PostgreSQL full-text search; pasar a un motor dedicado cuando relevancia, facetas o volumen lo requieran.
- IA: crear un módulo/gateway propio para políticas, presupuestos, logging, redacción de datos sensibles, selección de modelo y fallback. Elegir API externa o modelos autohospedados según costo, privacidad, latencia, calidad y operación GPU.
- No acoplar el dominio a un SDK específico de modelo/proveedor.

## Diseño de integración obligatoria

Para cada servicio externo, documentá:

- Interfaz/puerto interno y adaptador concreto.
- Autenticación del servicio, scopes y rotación de secretos.
- Timeout, retry con backoff y jitter, circuit breaker cuando aplique.
- Idempotencia y deduplicación.
- Límites, cuotas, rate limits y alertas de gasto.
- Tratamiento de fallas: fail-open, fail-closed, degradación o cola.
- Observabilidad: latencia, errores, volumen y costo.
- Exportación de datos, backup y plan de salida.
- Entorno sandbox, estrategia de pruebas de integración y runbook de incidentes.

No implementes retries indiscriminados: pueden amplificar una caída. Respetá idempotencia, presupuesto de tiempo y política del proveedor.

## Entregables obligatorios

1. Requisito y contexto de la decisión.
2. Comparación de build-in-app vs OSS self-hosted vs managed provider.
3. Matriz de ventajas, desventajas, riesgos, licencia y operación.
4. TCO con supuestos explícitos y datos pendientes.
5. Recomendación principal y condiciones que harían cambiarla.
6. Diseño del adaptador e interfaz interna.
7. Estrategia de seguridad, observabilidad, fallas y recuperación.
8. Plan de migración/salida y riesgo de lock-in.
9. ADR que registre por qué se eligió la opción.

## Referencias

Consultá `references/provider-evaluation.md` y verificá documentación y precios vigentes antes de recomendar un proveedor concreto.
